Name: Henry Wong
Email: hwong10@uoguelpg.ca
ID: 1057822

To compile the file, type "make" after moving a1.c and the makefile 
in the directory with all the require opengl files. Please note that the makefile is currently
set to compile on linux, and that if you are using mac, you have to uncomment/comment out the path line
in the makefile.

After the file is compiled, just type the normal ./a1 and it will generate the 9 rooms and hallways while
spawning you into a one of the rooms randomly with a randomly spawned yellow cube to test gravity.

Please turn off flightcontrol by pressing "f" after you spawn in and before moving around. It should turn
gravity and collision response. If you press "f" again, flightcontrol will be on and you can fly and go 
through blocks.

That should be all.